import json
import os
import re

# Folder containing the extracted JSON files
INPUT_FOLDER = "nlp-corpus"

# Output dataset
OUTPUT_FILE = "AriesLM_dataset.txt"


def find_text(value):
    """Recursively find strings inside JSON data."""
    if isinstance(value, str):
        return [value]

    if isinstance(value, dict):
        results = []
        for v in value.values():
            results.extend(find_text(v))
        return results

    if isinstance(value, list):
        results = []
        for v in value:
            results.extend(find_text(v))
        return results

    return []


tokens = []
json_files = 0

for root, dirs, files in os.walk(INPUT_FOLDER):
    for filename in files:
        if not filename.lower().endswith(".json"):
            continue

        path = os.path.join(root, filename)
        json_files += 1

        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)

            text_parts = find_text(data)

            for text in text_parts:
                # Split on whitespace
                tokens.extend(text.split())

        except Exception as e:
            print("Could not read:", path)
            print("Error:", e)


with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    for token in tokens:
        f.write(token + "\n")


print()
print("Done!")
print("JSON files processed:", json_files)
print("Tokens:", len(tokens))
print("Output:", OUTPUT_FILE)
